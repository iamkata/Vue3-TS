<template>
  <div class="nav-menu">
    <!-- 上面的logo -->
    <div class="logo">
      <!-- 在template中使用路径的别名是~@,这个和在js中不太一样,这里的~@就相当于src -->
      <!-- 鼠标放上去显示logo -->
      <img class="img" src="~@/assets/img/logo.svg" alt="logo" />
      <!-- v-if="!collapse" 折叠后隐藏文字 -->
      <span v-if="!collapse" class="title">Vue3+TS</span>
    </div>
    <!-- 下面的菜单 -->
    <!-- 最外面是el-menu,然后里面可以打开的是el-submenu,不能打开的是el-menu-item -->
    <!-- :collapse="collapse" 更新折叠状态 -->
    <el-menu
      :default-active="defaultValue"
      class="el-menu-vertical"
      :collapse="collapse"
      background-color="#0c2135"
      text-color="#b7bdc3"
      active-text-color="#0a60bd"
    >
      <template v-for="item in userMenus" :key="item.id">
        <!-- 有子菜单 -->
        <template v-if="item.type === 1">
          <!-- 二级菜单的可以展开的标题 -->
          <!-- :index="item.id 绑定一个唯一的标识 -->
          <el-submenu :index="item.id + ''">
            <!-- #title 具名插槽 -->
            <template #title>
              <!-- 设置图标 -->
              <i v-if="item.icon" :class="item.icon"></i>
              <span>{{ item.name }}</span>
            </template>
            <!-- 遍历里面的item -->
            <!-- 逻辑相关的东西最好都放template上面,这样会更清晰 -->
            <template v-for="subitem in item.children" :key="subitem.id">
              <!-- :index="subitem.id 绑定一个唯一的标识,用来表示选中哪个了 -->
              <el-menu-item
                :index="subitem.id + ''"
                @click="handleMenuItemClick(subitem)"
              >
                <i v-if="subitem.icon" :class="subitem.icon"></i>
                <span>{{ subitem.name }}</span>
              </el-menu-item>
            </template>
          </el-submenu>
        </template>
        <!-- 没有子菜单,一级菜单 -->
        <template v-else-if="item.type === 2">
          <el-menu-item :index="item.id + ''">
            <i v-if="item.icon" :class="item.icon"></i>
            <span>{{ item.name }}</span>
          </el-menu-item>
        </template>
      </template>
    </el-menu>
  </div>
</template>

<script lang="ts">
import { defineComponent, computed, ref } from 'vue'
// 使用我们自己的useStore
import { useStore } from '@/store'
import { useRouter, useRoute } from 'vue-router'

import { pathMapToMenu } from '@/utils/map-menus'

// vuex - typescript  => pinia

export default defineComponent({
  props: {
    // 接受父组件传递的折叠状态
    collapse: {
      type: Boolean,
      default: false
    }
  },
  setup() {
    // store
    const store = useStore()
    // 这里我们使用的是我们自己的useStore,方法传入了IStoreType泛型,这样我们使用store.state.login就不会报错了
    // 如果我们不用自己的useStore,那么在.login的时候会报错,这是因为vuex对typescript兼容性不太好的原因
    // 所以一般使用typescript,我们会使用pinia来代替vuex,因为pinia对typescript的兼容性更好
    // 用计算属性拿到用户菜单数据
    const userMenus = computed(() => store.state.login.userMenus)

    // router
    const router = useRouter()
    // 当前路由对象
    const route = useRoute()
    // 当前路由地址
    const currentPath = route.path

    // 根据当前路径,找到当前菜单对象
    // computed拿到的是ref对象,想要获取ref对象的值,就使用value
    const menu = pathMapToMenu(userMenus.value, currentPath)
    // 默认获取选中的菜单
    const defaultValue = ref(menu.id + '')

    // 菜单栏点击,进行路由跳转
    const handleMenuItemClick = (item: any) => {
      router.push({
        path: item.url ?? '/not-found'
      })
    }
    return {
      userMenus,
      defaultValue,
      handleMenuItemClick
    }
  }
})
</script>

<style scoped lang="less">
.nav-menu {
  height: 100%;
  background-color: #001529;

  .logo {
    display: flex;
    height: 28px;
    padding: 12px 10px 8px 10px;
    flex-direction: row;
    justify-content: flex-start;
    align-items: center;

    .img {
      height: 100%;
      margin: 0 10px;
    }

    .title {
      font-size: 16px;
      font-weight: 700;
      color: white;
    }
  }

  // 去掉竖线
  .el-menu {
    border-right: none;
  }

  // 目录
  .el-submenu {
    background-color: #001529 !important;
    // 二级菜单 ( 默认背景 )
    .el-menu-item {
      padding-left: 50px !important;
      background-color: #0c2135 !important;
    }
  }

  ::v-deep .el-submenu__title {
    background-color: #001529 !important;
  }

  // hover 高亮
  .el-menu-item:hover {
    color: #fff !important; // 菜单
  }

  .el-menu-item.is-active {
    color: #fff !important;
    background-color: #0a60bd !important;
  }
}

.el-menu-vertical:not(.el-menu--collapse) {
  width: 100%;
  height: calc(100% - 48px);
}
</style>
