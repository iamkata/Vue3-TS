<template>
  <div class="nav-header">
    <!-- 左侧菜单折叠的小图标 -->
    <i
      class="fold-menu"
      :class="isFold ? 'el-icon-s-fold' : 'el-icon-s-unfold'"
      @click="handleFoldClick"
    ></i>
    <div class="content">
      <!-- 面包屑组件 -->
      <hy-breadcrumb :breadcrumbs="breadcrumbs" />
      <!-- 使用用户信息组件 -->
      <user-info />
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, computed } from 'vue'
import UserInfo from './user-info.vue'
import HyBreadcrumb from '@/base-ui/breadcrumb'

import { useStore } from '@/store'
import { useRoute } from 'vue-router'
import { pathMapBreadcrumbs } from '@/utils/map-menus'

export default defineComponent({
  components: {
    UserInfo,
    HyBreadcrumb
  },
  emits: ['foldChange'],
  setup(props, { emit }) {
    // 默认不折叠
    const isFold = ref(false)
    const handleFoldClick = () => {
      isFold.value = !isFold.value
      // 子组件给父组件传值
      emit('foldChange', isFold.value)
    }

    // 面包屑的数据: [{name: , path: }]
    const store = useStore()
    // 计算属性如果对某个变量有依赖,如果依赖的数据改变了,计算属性会重新计算的
    // 使用计算属性,这样路径改变后,面包屑的数据才能实时改变
    const breadcrumbs = computed(() => {
      // 菜单数据
      const userMenus = store.state.login.userMenus
      // 当前路由
      const route = useRoute()
      // 当前地址
      const currentPath = route.path
      // 获取面包屑数组
      return pathMapBreadcrumbs(userMenus, currentPath)
    })

    return {
      isFold,
      handleFoldClick,
      breadcrumbs
    }
  }
})
</script>

<style scoped lang="less">
.nav-header {
  display: flex;
  width: 100%;

  .fold-menu {
    font-size: 30px;
    cursor: pointer;
  }

  .content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex: 1;
    padding: 0 20px;
  }
}
</style>
