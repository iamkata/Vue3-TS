<template>
  <div class="page-content">
    <!-- user.vue中导入contentTableConfig,然后传到page-content.vue中,然后再传到hy-table.vue中 -->
    <!-- contentTableConfig是个对象,将一个对象绑定到一个组件上就是将一个对象的所有属性一个一个绑定到组件上 -->
    <!-- 通过v-model将pageInfo绑定到hy-table上 -->
    <!-- v-model是可以起个名字的,如果不起名字,默认绑定是属性是modelValue,事件是update:modelValue -->
    <!-- 起名字为page后,默认绑定是属性是page,事件是update:page -->
    <hy-table
      :listData="dataList"
      :listCount="dataCount"
      v-bind="contentTableConfig"
      v-model:page="pageInfo"
    >
      <!-- 1.header中的插槽 -->
      <template #headerHandler>
        <el-button
          v-if="isCreate"
          type="primary"
          size="medium"
          @click="handleNewClick"
        >
          新建用户
        </el-button>
      </template>

      <!-- 2.列中的插槽 -->
      <!-- 禁用状态插槽 -->
      <template #status="scope">
        <!-- plain镂空效果 -->
        <!-- type不同类型的样式效果 -->
        <el-button
          plain
          size="mini"
          :type="scope.row.enable ? 'success' : 'danger'"
        >
          {{ scope.row.enable ? '启用' : '禁用' }}
        </el-button>
      </template>
      <!-- 创建时间插槽 -->
      <template #createAt="scope">
        <!-- 父组件拿到子组件的数据,然后加工显示 -->
        <span>{{ $filters.formatTime(scope.row.createAt) }}</span>
      </template>
      <template #updateAt="scope">
        <span>{{ $filters.formatTime(scope.row.updateAt) }}</span>
      </template>
      <!-- 编辑+删除 插槽 -->
      <template #handler="scope">
        <div class="handle-btns">
          <el-button
            v-if="isUpdate"
            icon="el-icon-edit"
            size="mini"
            type="text"
            @click="handleEditClick(scope.row)"
          >
            编辑
          </el-button>
          <el-button
            v-if="isDelete"
            icon="el-icon-delete"
            size="mini"
            type="text"
            @click="handleDeleteClick(scope.row)"
            >删除</el-button
          >
        </div>
      </template>

      <!-- page-content.vue只实现status createAt updateAt handler这些公共的插槽 -->
      <!-- 如果是其他界面专属的插槽,让那个界面实现,就比如goods.vue界面的image插槽和oldPrice插槽 -->

      <!-- 在page-content中动态插入剩余的插槽 -->
      <template
        v-for="item in otherPropSlots"
        :key="item.prop"
        #[item.slotName]="scope"
      >
        <template v-if="item.slotName">
          <slot :name="item.slotName" :row="scope.row"></slot>
        </template>
      </template>
    </hy-table>
  </div>
</template>

<script lang="ts">
import { defineComponent, computed, ref, watch } from 'vue'
import { useStore } from '@/store'
import { usePermission } from '@/hooks/use-permission'

import HyTable from '@/base-ui/table'

export default defineComponent({
  components: {
    HyTable
  },
  props: {
    contentTableConfig: {
      type: Object,
      require: true
    },
    // 当前页面的名字
    pageName: {
      type: String,
      required: true
    }
  },
  emits: ['newBtnClick', 'editBtnClick'],
  setup(props, { emit }) {
    const store = useStore()

    // 0.获取操作的权限
    const isCreate = usePermission(props.pageName, 'create')
    const isUpdate = usePermission(props.pageName, 'update')
    const isDelete = usePermission(props.pageName, 'delete')
    const isQuery = usePermission(props.pageName, 'query')

    // 1.双向绑定pageInfo
    const pageInfo = ref({ currentPage: 1, pageSize: 10 })
    // 监听分页信息的改变,分页信息改变后再重新请求数据
    watch(pageInfo, () => getPageData())

    // 2.发送网络请求
    const getPageData = (queryInfo: any = {}) => {
      if (!isQuery) return
      store.dispatch('system/getPageListAction', {
        pageName: props.pageName,
        queryInfo: {
          offset: (pageInfo.value.currentPage - 1) * pageInfo.value.pageSize,
          size: pageInfo.value.pageSize,
          ...queryInfo
        }
      })
    }
    getPageData()

    // 3.从vuex中获取数据
    let dataList = computed(() =>
      // 调用getters函数,并且传入参数
      store.getters[`system/pageListData`](props.pageName)
    )
    // 总数据多少条
    let dataCount = computed(() =>
      store.getters[`system/pageListCount`](props.pageName)
    )
    //用户列表
    //角色列表
    //菜单列表
    //商品列表
    // 如果网络加载不到数据,就加载本地数据,这里使用的是回调函数,待优化
    // let pageResult = {} as any
    // getJsonData.getJsonDataWithStr(props.pageName + 'List', function (resData) {
    //   pageResult = resData
    //   dataList = pageResult.data.list
    //   dataCount = pageResult.data.totalCount
    //   console.log('本地数据')
    //   console.log(pageResult)
    //   console.log(dataList)
    //   console.log(dataCount)
    // })

    // 4.获取其他的动态插槽名称 公共的插槽排除掉
    const otherPropSlots = props.contentTableConfig?.propList.filter(
      (item: any) => {
        if (item.slotName === 'status') return false
        if (item.slotName === 'createAt') return false
        if (item.slotName === 'updateAt') return false
        if (item.slotName === 'handler') return false
        return true
      }
    )

    // 5.删除/编辑/新建操作
    const handleDeleteClick = (item: any) => {
      // console.log(item)
      store.dispatch('system/deletePageDataAction', {
        pageName: props.pageName,
        id: item.id
      })
    }
    const handleNewClick = () => {
      emit('newBtnClick')
    }
    const handleEditClick = (item: any) => {
      emit('editBtnClick', item)
    }

    return {
      dataList,
      getPageData,
      dataCount,
      pageInfo,
      otherPropSlots,
      isCreate,
      isUpdate,
      isDelete,
      handleDeleteClick,
      handleNewClick,
      handleEditClick
    }
  }
})
</script>

<style scoped>
.page-content {
  padding: 20px;
  border-top: 20px solid #f5f5f5;
}
</style>
