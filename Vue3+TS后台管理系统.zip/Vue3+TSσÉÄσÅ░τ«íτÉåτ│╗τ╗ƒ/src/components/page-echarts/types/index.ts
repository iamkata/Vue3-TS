export interface IDataType {
  name: string
  value: any
}
