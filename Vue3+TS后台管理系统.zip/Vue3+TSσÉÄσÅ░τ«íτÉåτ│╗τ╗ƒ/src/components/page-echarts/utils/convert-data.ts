// 拿到城市和经纬度对应的数据
import { coordinateData } from './coordinate-data'

// 将城市对应的数据放到value数组里面
export const convertData = function (data: any) {
  const res = []
  for (let i = 0; i < data.length; i++) {
    const geoCoord = coordinateData[data[i].name]
    if (geoCoord) {
      res.push({
        name: data[i].name,
        // [113.23, 23.26, 216]
        value: geoCoord.concat(data[i].value)
      })
    } 
  }
  return res
}
