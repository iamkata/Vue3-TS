<template>
  <div class="role">
    <page-search :searchFormConfig="searchFormConfig"></page-search>
    <page-content
      :contentTableConfig="contentTableConfig"
      pageName="role"
      @newBtnClick="handleNewData"
      @editBtnClick="handleEditData"
    ></page-content>
    <!-- 编辑角色弹窗 -->
    <!-- 将otherInfo传递给子组件 -->
    <page-modal
      ref="pageModalRef"
      :defaultInfo="defaultInfo"
      :otherInfo="otherInfo"
      :modalConfig="modalConfig"
      pageName="role"
    >
      <!-- 这些内容会在默认插槽里面 -->
      <!-- props是个对象,children是指定用哪个字段作为子菜单,label是指定用什么字段来显示 -->
      <div class="menu-tree">
        <el-tree
          ref="elTreeRef"
          :data="menus"
          show-checkbox
          node-key="id"
          :props="{ children: 'children', label: 'name' }"
          @check="handleCheckChange"
        >
        </el-tree>
      </div>
    </page-modal>
  </div>
</template>

<script lang="ts">
import { defineComponent, computed, ref, nextTick } from 'vue'
import { useStore } from '@/store'
import { menuMapLeafKeys } from '@/utils/map-menus'

import { ElTree } from 'element-plus'
import PageSearch from '@/components/page-search'
import PageContent from '@/components/page-content'
import PageModal from '@/components/page-modal'

import { searchFormConfig } from './config/search.config'
import { contentTableConfig } from './config/content.config'
import { modalConfig } from './config/modal.config'

import { usePageModal } from '@/hooks/use-page-modal'

export default defineComponent({
  name: 'role',
  components: {
    PageContent,
    PageSearch,
    PageModal
  },
  setup() {
    // 1.处理pageModal的hook
    // 拿到er-tree的引用
    const elTreeRef = ref<InstanceType<typeof ElTree>>()
    // 点击编辑按钮的回调
    const editCallback = (item: any) => {
      // 获取所有的叶子节点
      const leafKeys = menuMapLeafKeys(item.menuList)
      // 由于点击编辑的时候就会调用callback,但是这时候elTreeRef还没有绑定呢,所以下面打印的是undefined
      // 所以我们使用nextTick,就是等到下一帧的时候再去做这个操作
      nextTick(() => {
        console.log(elTreeRef.value)
        // 给所有的叶子节点设置选中
        elTreeRef.value?.setCheckedKeys(leafKeys, false)
      })
    }
    const [pageModalRef, defaultInfo, handleNewData, handleEditData] =
      usePageModal(undefined, editCallback)

    // 拿到权限菜单数据
    const store = useStore()
    const menus = computed(() => store.state.entireMenu)

    // otherInfo就是选中的菜单数据,要是响应式的
    const otherInfo = ref({})
    // 选中之后调用的方法
    const handleCheckChange = (data1: any, data2: any) => {
      const checkedKeys = data2.checkedKeys
      const halfCheckedKeys = data2.halfCheckedKeys
      const menuList = [...checkedKeys, ...halfCheckedKeys]
      // menuList是ES6的语法糖,就是menuList: menuList的意思
      otherInfo.value = { menuList }
    }

    return {
      searchFormConfig,
      contentTableConfig,
      modalConfig,
      pageModalRef,
      defaultInfo,
      handleNewData,
      handleEditData,
      menus,
      otherInfo,
      handleCheckChange,
      elTreeRef
    }
  }
})
</script>

<style scoped lang="less">
.menu-tree {
  margin-left: 25px;
}
</style>
