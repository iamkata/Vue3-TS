<template>
  <div class="main">
    <!-- 总体 -->
    <el-container class="main-content">
      <!-- 侧边栏 -->
      <el-aside :width="isCollapse ? '60px' : '210px'">
        <!-- 菜单组件 -->
        <!-- 将折叠状态传给nav-menu,让它做相应的状态切换 -->
        <nav-menu :collapse="isCollapse" />
      </el-aside>
      <!-- 右侧区域 -->
      <el-container class="page">
        <!-- 头部 -->
        <el-header class="page-header">
          <!-- 头部组件 -->
          <nav-header @foldChange="handleFoldChange" />
        </el-header>
        <!-- main -->
        <el-main class="page-content">
          <!-- 外面包裹一下,添加白色背景 -->
          <div class="page-info">
            <!-- 路由占位符 -->
            <router-view></router-view>
          </div>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'
import NavMenu from '@/components/nav-menu'
import NavHeader from '@/components/nav-header'

export default defineComponent({
  components: {
    NavMenu,
    NavHeader
  },
  setup() {
    // 记录下当前是否折叠
    const isCollapse = ref(false)
    const handleFoldChange = (isFold: boolean) => {
      isCollapse.value = isFold
    }

    return {
      isCollapse,
      handleFoldChange
    }
  }
})
</script>

<style scoped lang="less">
.main {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}

.main-content,
.page {
  height: 100%;
}

.page-content {
  height: calc(100% - 48px);

  .page-info {
    background-color: #fff;
    border-radius: 5px;
  }
}

.el-header,
.el-footer {
  display: flex;
  color: #333;
  text-align: center;
  align-items: center;
}

.el-header {
  height: 48px !important;
}

.el-aside {
  overflow-x: hidden;
  overflow-y: auto;
  line-height: 200px;
  text-align: left;
  cursor: pointer;
  background-color: #001529;
  transition: width 0.3s linear;
  scrollbar-width: none; /* firefox */
  -ms-overflow-style: none; /* IE 10+ */

  &::-webkit-scrollbar {
    display: none;
  }
}

.el-main {
  color: #333;
  text-align: center;
  background-color: #f0f2f5;
}
</style>
