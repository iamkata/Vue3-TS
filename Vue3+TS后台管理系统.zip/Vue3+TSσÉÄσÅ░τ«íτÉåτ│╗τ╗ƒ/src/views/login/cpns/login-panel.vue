<template>
  <div class="login-panel">
    <!-- 中间登录面板组件 -->
    <h1 class="title">后台管理系统</h1>
    <!-- 使用tab组件 -->
    <!-- stretch平分的效果 -->
    <!-- v-model="currentTab"当前选项卡 -->
    <el-tabs type="border-card" stretch v-model="currentTab">
      <!-- name="account"这个选项卡的名字是account,在选中的时候会绑定到currentTab上面,从而记录下来 -->
      <el-tab-pane name="account">
        <template #label>
          <span><i class="el-icon-user-solid"></i> 账号登录</span>
        </template>
        <login-account ref="accountRef" />
      </el-tab-pane>
      <el-tab-pane name="phone">
        <template #label>
          <span><i class="el-icon-mobile-phone"></i> 手机登录</span>
        </template>
        <login-phone ref="phoneRef" />
      </el-tab-pane>
    </el-tabs>

    <!-- 记住密码/忘记密码 -->
    <div class="account-control">
      <el-checkbox v-model="isKeepPassword">记住密码</el-checkbox>
      <el-link type="primary">忘记密码</el-link>
    </div>
    <!-- 立即登录 -->
    <el-button type="primary" class="login-btn" @click="handleLoginClick"
      >立即登录</el-button
    >
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'
import LoginAccount from './login-account.vue'
import LoginPhone from './login-phone.vue'

export default defineComponent({
  components: {
    LoginAccount,
    LoginPhone
  },
  setup() {
    // 1.定义属性
    // 是否记住密码
    const isKeepPassword = ref(true)
    // login-account组件的引用, 并且给组件指定泛型类型,并且刚开始没赋值
    // 如果不指定泛型,默认就是any,虽然不报错,但是代码不严谨
    // const p = ref<Person>() 和 const p = ref<InstanceType<typeof Person>>() 意思是一样的
    // Coderwhy的原话是中间的那一串是获取拥有构造函数的示例,但是我感觉这样不好理解,我感觉就是组件实例的类型
    const accountRef = ref<InstanceType<typeof LoginAccount>>()
    // login-phone组件的引用
    const phoneRef = ref<InstanceType<typeof LoginPhone>>()
    // 默认选中账密登录
    const currentTab = ref('account')

    // 2.定义方法
    // 点击立即登录按钮
    const handleLoginClick = () => {
      // 是账密登录
      if (currentTab.value === 'account') {
        // 因为刚开始没赋值,所以下面调用的时候需要加?
        accountRef.value?.loginAction(isKeepPassword.value)
      } else {
        console.log('phoneRef调用loginAction')
      }
    }

    return {
      isKeepPassword,
      accountRef,
      phoneRef,
      currentTab,
      handleLoginClick
    }
  }
})
</script>

<style scoped lang="less">
.login-panel {
  margin-bottom: 150px;
  width: 320px;

  .title {
    text-align: center;
  }

  .account-control {
    display: flex;
    justify-content: space-between;
    margin-top: 10px;
  }

  .login-btn {
    width: 100%;
    margin-top: 10px;
  }
}
</style>
