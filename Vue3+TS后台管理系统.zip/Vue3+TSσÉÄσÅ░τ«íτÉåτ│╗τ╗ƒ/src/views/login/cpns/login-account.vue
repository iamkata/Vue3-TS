<template>
  <div class="login-account">
    <!-- 账号密码登录组件 -->
    <!-- el-form 拿到rules和account就可以对比输入的是否符合规则了 -->
    <el-form label-width="60px" :rules="rules" :model="account" ref="formRef">
      <!-- prop="name"代表验证account里面的name规则  -->
      <el-form-item label="账号" prop="name">
        <el-input v-model="account.name" />
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <!-- show-password 密文显示 -->
        <el-input v-model="account.password" show-password />
      </el-form-item>
    </el-form>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref } from 'vue'
import { useStore } from 'vuex'
// 拿到ElForm类型来用
import { ElForm } from 'element-plus'
// 也就是'src/utils/cache' 因为tsconfig.json里面配置过路径别名
import localCache from '@/utils/cache'
//导入验证规则
import { rules } from '../config/account-config'

export default defineComponent({
  setup() {
    // 获取实例
    const store = useStore()

    const account = reactive({
      // 从本地获取姓名和密码
      name: localCache.getCache('name') ?? '',
      password: localCache.getCache('password') ?? ''
    })
    // 给el-form绑定ref,并指定类型
    const formRef = ref<InstanceType<typeof ElForm>>()

    // 登录逻辑
    const loginAction = (isKeepPassword: boolean) => {
      // formRef.value就是获取的form实例
      formRef.value?.validate((valid) => {
        // 验证成功才往下走
        if (valid) {
          // 1.判断是否需要记住密码
          if (isKeepPassword) {
            // 本地缓存
            localCache.setCache('name', account.name)
            localCache.setCache('password', account.password)
          } else {
            //清空缓存
            localCache.deleteCache('name')
            localCache.deleteCache('password')
          }
          // 2.开始进行登录验证
          // 指定login模块的dispatch  参数进行解构
          store.dispatch('login/accountLoginAction', { ...account })
        }
      })
    }
    return {
      account,
      rules,
      loginAction,
      formRef
    }
  }
})
</script>

<style scoped></style>
