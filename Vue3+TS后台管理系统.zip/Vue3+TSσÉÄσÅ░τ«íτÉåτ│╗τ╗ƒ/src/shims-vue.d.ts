/* eslint-disable */
// 声明.vue的类型,这样我们的项目就可以使用.vue文件了
declare module '*.vue' {
  import type { DefineComponent } from 'vue'
  const component: DefineComponent<{}, {}, any>
  export default component
}

declare let $store: any
// 声明json文件,这样vue就能识别了
declare module '*.json'
