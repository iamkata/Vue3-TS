// 导入网络请求
import hyRequest from '../index'
//导入定义的类型
import { IAccount, ILoginResult } from './type'
// 导入服务器返回的类型
import { IDataType } from '../types'

// 定义url枚举
enum LoginAPI {
  AccountLogin = '/login',
  LoginUserInfo = '/users/', // 用法: /users/1
  UserMenus = '/role/' // 用法: role/1/menu
}

//账密登录请求
export function accountLoginRequest(account: IAccount) {
  // post请求传入泛型,这样请求的结果的类型我们就能确定了
  return hyRequest.post<IDataType<ILoginResult>>({
    url: LoginAPI.AccountLogin,
    data: account
  })
}

//请求用户信息
export function requestUserInfoById(id: number) {
  // 由于用户信息比较复杂,所以data的泛型就不传了,默认就是any
  return hyRequest.get<IDataType>({
    url: LoginAPI.LoginUserInfo + id,
    showLoading: false
  })
}

// 请求用户菜单
export function requestUserMenusByRoleId(id: number) {
  return hyRequest.get<IDataType>({
    url: LoginAPI.UserMenus + id + '/menu',
    showLoading: false
  })
}
