// 定义服务器返回的类型
// data的类型不确定,默认是any
export interface IDataType<T = any> {
  code: number
  data: T
}
