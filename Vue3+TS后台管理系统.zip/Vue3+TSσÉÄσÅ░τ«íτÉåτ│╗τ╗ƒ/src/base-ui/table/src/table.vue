<template>
  <div class="hy-table">
    <div class="header">
      <!-- 总的插槽 -->
      <slot name="header">
        <!-- 但是一般的header都是有一个标题的(左侧),所以我们可以提供默认实现外面可以传标题进来-->
        <div class="title">{{ title }}</div>
        <div class="handler">
          <!-- 默认实现里面也有插槽 -->
          <slot name="headerHandler"></slot>
        </div>
      </slot>
    </div>
    <!-- 选中的时候会触发handleSelectionChange事件 -->
    <!-- v-bind="childrenProps" 二三级菜单对应的属性 -->
    <el-table
      :data="listData"
      border
      style="width: 100%"
      @selection-change="handleSelectionChange"
      v-bind="childrenProps"
    >
      <!-- 是否显示选中列 -->
      <el-table-column
        v-if="showSelectColumn"
        type="selection"
        align="center"
        width="60"
      ></el-table-column>
      <!-- 是否显示序列号列 -->
      <el-table-column
        v-if="showIndexColumn"
        type="index"
        label="序号"
        align="center"
        width="80"
      ></el-table-column>
      <template v-for="propItem in propList" :key="propItem.prop">
        <el-table-column v-bind="propItem" align="center" show-overflow-tooltip>
          <!-- el-table-column就是table.vue的子组件,所以在这里父组件中,通过scope.row拿到这一行的数据 -->
          <template #default="scope">
            <!-- 插槽名字是动态的 -->
            <!-- scope.row就是这一行的数据 -->
            <!-- :row="scope.row" 将这一行的数据传给父组件(page-content.vue)加工 -->
            <!-- 如果父组件实现了命名插槽,就会根据子组件传过去的数据,加工,然后替换命名插槽 -->
            <slot :name="propItem.slotName" :row="scope.row">
              <!-- 显示原始数据 -->
              {{ scope.row[propItem.prop] }}
            </slot>
          </template>
        </el-table-column>
      </template>
    </el-table>
    <div class="footer" v-if="showFooter">
      <slot name="footer">
        <!-- 默认是个分页器 -->
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="page.currentPage"
          :page-size="page.pageSize"
          :page-sizes="[10, 20, 30]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="listCount"
        >
        </el-pagination>
      </slot>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  props: {
    title: {
      type: String,
      default: ''
    },
    listData: {
      type: Array,
      required: true
    },
    listCount: {
      type: Number,
      default: 0
    },
    propList: {
      type: Array,
      required: true
    },
    showIndexColumn: {
      type: Boolean,
      default: false
    },
    showSelectColumn: {
      type: Boolean,
      default: false
    },
    page: {
      type: Object,
      default: () => ({ currentPage: 0, pageSize: 10 })
    },
    // 二三级菜单对应的属性
    childrenProps: {
      type: Object,
      default: () => ({})
    },
    showFooter: {
      type: Boolean,
      default: true
    }
  },
  emits: ['selectionChange', 'update:page'],
  setup(props, { emit }) {
    // 将选中的数据传递给父组件
    const handleSelectionChange = (value: any) => {
      emit('selectionChange', value)
    }
    // 页码改变
    const handleCurrentChange = (currentPage: number) => {
      // 将更新后的page对象传给父组件
      emit('update:page', { ...props.page, currentPage })
    }
    // 页码数目改变
    const handleSizeChange = (pageSize: number) => {
      emit('update:page', { ...props.page, pageSize })
    }

    return {
      handleSelectionChange,
      handleCurrentChange,
      handleSizeChange
    }
  }
})
</script>

<style scoped lang="less">
.header {
  display: flex;
  height: 45px;
  padding: 0 5px;
  justify-content: space-between;
  align-items: center;

  .title {
    font-size: 20px;
    font-weight: 700;
  }

  .handler {
    align-items: center;
  }
}

.footer {
  margin-top: 15px;

  .el-pagination {
    text-align: right;
  }
}
</style>
