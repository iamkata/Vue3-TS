import HyCouterUp from './src/countup.vue'

export default HyCouterUp
