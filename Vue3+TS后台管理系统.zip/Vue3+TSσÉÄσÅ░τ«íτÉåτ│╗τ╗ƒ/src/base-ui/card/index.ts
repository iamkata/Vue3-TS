import HyCard from './src/card.vue'

export default HyCard
