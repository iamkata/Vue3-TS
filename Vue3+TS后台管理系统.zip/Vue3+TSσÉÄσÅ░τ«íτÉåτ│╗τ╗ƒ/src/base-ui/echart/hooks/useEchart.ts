import * as echarts from 'echarts'

// 导入地图数据
import chinaMapData from '../data/china.json'
// 注册地图 注册了一个地图叫china,以后就可以用了
echarts.registerMap('china', chinaMapData)

// 默认导出一个方法,返回一个对象,对象里是一个实例,两个方法
// 为什么直接导出的是对象不是数组呢?如果是数组,里面的属性都要一个一个拿出来对应起来,如果是对象就可以直接解构我们需要的属性
export default function (el: HTMLElement) {
  // 1. 初始化echarts实例
  const echartInstance = echarts.init(el)
  // 2. 设值配置,并且开始绘制
  const setOptions = (options: echarts.EChartsOption) => {
    echartInstance.setOption(options)
  }

  // 当我们是手动折叠菜单栏的时候,这时候不是window的resize事件,就需要我们主动调用了
  const updateSize = () => {
    echartInstance.resize()
  }

  // 监听resize
  window.addEventListener('resize', () => {
    // 让图形自己改变
    echartInstance.resize()
  })

  return {
    echartInstance,
    setOptions,
    updateSize
  }
}
