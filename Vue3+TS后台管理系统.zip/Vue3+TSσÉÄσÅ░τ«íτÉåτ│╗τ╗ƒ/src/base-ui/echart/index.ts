import BaseEchart from './src/base-echart.vue'

export default BaseEchart
