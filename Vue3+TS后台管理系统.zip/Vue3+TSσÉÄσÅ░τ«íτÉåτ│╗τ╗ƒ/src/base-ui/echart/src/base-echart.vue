<template>
  <div class="base-echart">
    <!-- 宽高是外面传过来的 -->
    <div ref="echartDivRef" :style="{ width: width, height: height }"></div>
  </div>
</template>

<script lang="ts" setup>
// vue3.2.0以后<script setup>就被加入正式版了,我们可以使用了
import { ref, onMounted, defineProps, withDefaults, watchEffect } from 'vue'
import { EChartsOption } from 'echarts'
import useEchart from '../hooks/useEchart'

// <script setup>中使用defineProps定义props
// withDefaults函数第二个参数定义默认值
const props = withDefaults(
  defineProps<{
    options: EChartsOption
    width?: string
    height?: string
  }>(),
  {
    width: '100%',
    height: '360px'
  }
)

const echartDivRef = ref<HTMLElement>()

// 要在onMounted挂载之后再使用echartDivRef,否则echartDivRef.value没有值
// 因为setup代码执行的时候,模板还没加载完,这时候echartDivRef.value是没有值的
onMounted(() => {
  const { setOptions } = useEchart(echartDivRef.value!)

  // 我们要监听base-echart的options改变,在改变后重新调用setOptions刷新图表
  watchEffect(() => {
    setOptions(props.options)
  })
})
</script>

<style scoped></style>
