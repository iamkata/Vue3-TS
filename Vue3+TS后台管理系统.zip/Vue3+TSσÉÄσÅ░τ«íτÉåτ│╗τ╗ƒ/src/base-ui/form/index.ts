import HyForm from './src/form.vue'

// 导出所有类型
export * from './types'

export default HyForm
