// 公共的代码抽取到hook里面

import { ref } from 'vue'
import PageModal from '@/components/page-modal'

// 定义回调
type CallbackFn = (item?: any) => void

// 为什么这里导出返回的就是数组而不是对象呢?因为数组里面的东西我们都会用到,所以可以一个一个列出来,当然用对象也是可以的
export function usePageModal(newCb?: CallbackFn, editCb?: CallbackFn) {
  const pageModalRef = ref<InstanceType<typeof PageModal>>()
  // 新建用户,默认数据是{}
  const defaultInfo = ref({})
  const handleNewData = () => {
    defaultInfo.value = {}
    if (pageModalRef.value) {
      pageModalRef.value.dialogVisible = true
    }
    newCb && newCb()
  }
  const handleEditData = (item: any) => {
    // 编辑用户,默认数据是传进来的参数的拷贝
    defaultInfo.value = { ...item }
    if (pageModalRef.value) {
      pageModalRef.value.dialogVisible = true
    }
    // 将编辑的item传递过去
    editCb && editCb(item)
  }
  return [pageModalRef, defaultInfo, handleNewData, handleEditData]
}
