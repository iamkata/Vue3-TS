import { ref } from 'vue'
// 导入组件
import PageContent from '@/components/page-content'

export function usePageSearch() {
  // page-content组件的引用
  const pageContentRef = ref<InstanceType<typeof PageContent>>()
  const handleResetClick = () => {
    // 调用方法
    pageContentRef.value?.getPageData()
  }
  const handleQueryClick = (queryInfo: any) => {
    pageContentRef.value?.getPageData(queryInfo)
  }
  return [pageContentRef, handleResetClick, handleQueryClick]
}
