class LocalCache {
  // 使用类是因为类的封装性更好
  //存到本地, 任何类型都可以
  setCache(key: string, value: any) {
    window.localStorage.setItem(key, JSON.stringify(value))
  }
  //从本地获取
  getCache(key: string) {
    // obj => string => obj
    const value = window.localStorage.getItem(key)
    if (value) {
      // 将字符串转成对象
      return JSON.parse(value)
    }
  }
  //本地删除
  deleteCache(key: string) {
    window.localStorage.removeItem(key)
  }
  //清空
  clearCache() {
    window.localStorage.clear()
  }
}

// 导出实例对象
export default new LocalCache()
