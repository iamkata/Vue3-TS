// 通过npm install dayjs 安装这个库
import dayjs from 'dayjs'
import utc from 'dayjs/plugin/utc'

// 加入dayjs的扩展
dayjs.extend(utc)

// 格式
const DATE_TIME_FORMAT = 'YYYY-MM-DD HH:mm:ss'

export function formatUtcString(
  utcString: string,
  format: string = DATE_TIME_FORMAT
) {
  // utcOffset(8) 因为我们是东八区,所以要偏移8小时
  return dayjs.utc(utcString).utcOffset(8).format(format)
}

// export function formatTimestamp(
//   timestamp: number,
//   format: string = DATE_TIME_FORMAT
// ) {
//   return ''
// }
