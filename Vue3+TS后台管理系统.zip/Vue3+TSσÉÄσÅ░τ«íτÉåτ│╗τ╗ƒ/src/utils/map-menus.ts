import { IBreadcrumb } from '@/base-ui/breadcrumb'
// 导入路由类型
import { RouteRecordRaw } from 'vue-router'
// 第一个菜单
let firstMenu: any = null

// 返回值是RouteRecordRaw类型的数组
export function mapMenusToRoutes(userMenus: any[]): RouteRecordRaw[] {
  const routes: RouteRecordRaw[] = []

  // 1.先去加载默认所有的routes
  const allRoutes: RouteRecordRaw[] = []
  // require.context 可以直接使用,因为是webpack的东西
  // 第一个参数是查找的路径,第二个参数是是否递归查找文件夹, 第三个参数是匹配规则, 我们查找的是.ts结尾的文件
  const routeFiles = require.context('../router/main', true, /\.ts/)
  // 数组里面的内容是相对于main文件夹下的每个ts文件的文件路径 比如:./system/user/user.ts
  routeFiles.keys().forEach((key) => {
    // key.split('.')[1] 通过.来切割,再获取后面的内容,就相当于把.去掉
    // 获取的是文件导出的对象
    const route = require('../router/main' + key.split('.')[1])
    // 将路由对象放到数组中
    allRoutes.push(route.default)
  })

  // 2.根据菜单获取需要添加的routes
  // userMenus:
  // type === 1 -> children -> type === 1
  // type === 2 -> url -> route
  const _recurseGetRoute = (menus: any[]) => {
    for (const menu of menus) {
      if (menu.type === 2) {
        // 找到菜单对应的路由
        const route = allRoutes.find((route) => route.path === menu.url)
        // 找到之后放到数组中
        if (route) routes.push(route)
        // 保存第一个菜单
        if (!firstMenu) {
          firstMenu = menu
        }
      } else {
        // 递归调用
        _recurseGetRoute(menu.children)
      }
    }
  }

  // 调用函数
  _recurseGetRoute(userMenus)

  // 将动态路由返回出去
  return routes
}

// 获取面包屑数组
export function pathMapBreadcrumbs(userMenus: any[], currentPath: string) {
  const breadcrumbs: IBreadcrumb[] = []
  pathMapToMenu(userMenus, currentPath, breadcrumbs)
  return breadcrumbs
}

// 根据路径匹配对应的菜单
// /main/system/role  -> type === 2 对应menu
export function pathMapToMenu(
  userMenus: any[],
  currentPath: string,
  breadcrumbs?: IBreadcrumb[]
): any {
  for (const menu of userMenus) {
    if (menu.type === 1) {
      // 递归调用,找菜单
      const findMenu = pathMapToMenu(menu.children ?? [], currentPath)
      if (findMenu) {
        breadcrumbs?.push({ name: menu.name })
        breadcrumbs?.push({ name: findMenu.name })
        return findMenu
      }
    } else if (menu.type === 2 && menu.url === currentPath) {
      return menu
    }
  }
}

// 获取用户权限数组
export function mapMenusToPermissions(userMenus: any[]) {
  const permissions: string[] = []

  // 递归调用
  const _recurseGetPermission = (menus: any[]) => {
    for (const menu of menus) {
      if (menu.type === 1 || menu.type === 2) {
        _recurseGetPermission(menu.children ?? [])
      } else if (menu.type === 3) {
        permissions.push(menu.permission)
      }
    }
  }
  _recurseGetPermission(userMenus)

  return permissions
}

// 获取菜单里面的叶子节点
export function menuMapLeafKeys(menuList: any[]) {
  const leftKeys: number[] = []
  // 递归
  const _recurseGetLeaf = (menuList: any[]) => {
    for (const menu of menuList) {
      if (menu.children) {
        _recurseGetLeaf(menu.children)
      } else {
        leftKeys.push(menu.id)
      }
    }
  }
  _recurseGetLeaf(menuList)

  return leftKeys
}

// 将第一个菜单导出
export { firstMenu }
