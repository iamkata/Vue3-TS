// 导入Module类型
import { Module } from 'vuex'

// 导入登录调用的方法
import {
  accountLoginRequest,
  requestUserInfoById,
  requestUserMenusByRoleId
} from '@/service/login/login'
import localCache from '@/utils/cache'
import { mapMenusToRoutes, mapMenusToPermissions } from '@/utils/map-menus'
import router from '@/router'

import { IAccount } from '@/service/login/type'
// 导入state类型
import { ILoginState } from './types'
import { IRootState } from '../types'

import getJsonData from '../../global/getJsonData'

// 指定类型
// Module必须传入泛型类型,其中第一个泛型是模块中state的类型,第二个泛型是根模块state的类型
const loginModule: Module<ILoginState, IRootState> = {
  // 命名空间
  namespaced: true,
  state() {
    return {
      token: '',
      userInfo: {},
      userMenus: [],
      permissions: []
    }
  },
  getters: {},
  mutations: {
    changeToken(state, token: string) {
      state.token = token
    },
    changeUserInfo(state, userInfo: any) {
      state.userInfo = userInfo
    },
    changeUserMenus(state, userMenus: any) {
      state.userMenus = userMenus

      // 根据菜单创建路由
      // userMenus => routes
      const routes = mapMenusToRoutes(userMenus)

      // 将路由添加为main的子路由
      // 将routes => router.main.children
      routes.forEach((route) => {
        // 将路由添加到main的children里面
        router.addRoute('main', route)
      })

      // 获取用户按钮的权限
      const permissions = mapMenusToPermissions(userMenus)
      state.permissions = permissions
    }
  },
  actions: {
    // 账号密码登录的action
    // 网络请求返回的是promise对象,所以可以直接使用async await
    async accountLoginAction({ commit, dispatch }, payload: IAccount) {
      // 1.实现登录逻辑
      let loginResult = await accountLoginRequest(payload)
      // 如果网络加载不到数据,就加载本地数据,这里使用的是回调函数,待优化
      if (!loginResult) {
        getJsonData.getJsonDataWithStr('login', function (resData) {
          loginResult = resData
        })
      }
      // 解构id和token
      const { id, token } = loginResult.data
      // 将token保存到上面去
      // 修改stage里面的数据只能通过mutations,所以我们通过commit('changeToken', token)保存数据
      commit('changeToken', token)
      // 将token保存到本地
      localCache.setCache('token', token)

      // 发送初始化的请求获取完整的role/department信息,这些信息一定要在token获取到之后才能获取
      // 在模块里面,如果直接调用action,默认调用的是这个模块的action,如果我们想调用根的action,需要第二个参数传null,第三个参数传root: true
      dispatch('getInitialDataAction', null, { root: true })

      // 2.请求用户信息
      let userInfoResult = await requestUserInfoById(id)
      //如果网络加载不到数据,就加载本地数据,这里使用的是回调函数,待优化
      if (!userInfoResult) {
        getJsonData.getJsonDataWithStr('userInfo', function (resData) {
          userInfoResult = resData
        })
      }
      const userInfo = userInfoResult.data
      commit('changeUserInfo', userInfo)
      localCache.setCache('userInfo', userInfo)

      // 3.跳到首页之前,请求用户菜单
      let userMenusResult = await requestUserMenusByRoleId(userInfo.role.id)
      //如果网络加载不到数据,就加载本地数据,这里使用的是回调函数,待优化
      if (!userMenusResult) {
        getJsonData.getJsonDataWithStr('userMenus', function (resData) {
          userMenusResult = resData
        })
      }
      const userMenus = userMenusResult.data
      commit('changeUserMenus', userMenus)
      localCache.setCache('userMenus', userMenus)

      // 4.跳到首页
      router.push('/main')
    },
    // 如果登录后,再访问其他界面,那么vuex中的数据(在内存中)就没了,所以每次刷新界面的时候重新请求数据,然后存到内存中
    // 在main.ts中会调用这个方法
    loadLocalLogin({ commit, dispatch }) {
      const token = localCache.getCache('token')
      if (token) {
        commit('changeToken', token)
        // 发送初始化的请求(完整的role/department)
        dispatch('getInitialDataAction', null, { root: true })
      }
      const userInfo = localCache.getCache('userInfo')
      if (userInfo) {
        commit('changeUserInfo', userInfo)
      }
      const userMenus = localCache.getCache('userMenus')
      if (userMenus) {
        commit('changeUserMenus', userMenus)
      }
    }
  }
}

export default loginModule
