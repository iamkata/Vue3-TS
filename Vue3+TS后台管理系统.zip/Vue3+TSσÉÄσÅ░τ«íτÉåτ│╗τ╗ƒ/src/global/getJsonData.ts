import axios from 'axios'

type CallbackFn = (item?: any) => void

//根据文件名获取文件数据
function getJsonDataWithStr(str: string, callBack: CallbackFn) {
  if (str) {
    //获取假数据
    axios.get('http://localhost:8080/json/' + str + '.json').then((res) => {
      callBack && callBack(res.data)
    })
  }
}

export default { getJsonDataWithStr }
